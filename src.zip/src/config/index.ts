import { ChainId } from '@sushiswap/sdk'

const config = {
  [ChainId.MAINNET]: {},
}

export default config
