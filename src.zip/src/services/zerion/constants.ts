export const ZERION_API = 'wss://api-v4.zerion.io/socket.io'
export const ZERION_API_KEY = 'Sushi.jwhvesUAPzqxzwMdQUNvyMGQrFfKiwXD'
